// src/components/ListaAnimais.js
import React from 'react';

const ListaAnimais = ({ animais, onRemover, onAlterarStatus }) => {
  return (
    <div>
      <h2>Lista de Animais Cadastrados</h2>
      <ul>
        {animais.map((animal, index) => (
          <li key={index}>
            <img src={animal.foto} alt="Foto do Animal" />
            <p>Raça: {animal.raca}</p>
            <p>Local: {animal.local}</p>
            <p>Tipo: {animal.tipo}</p>
            <p>Contato: {animal.contato}</p>
            <button onClick={() => onRemover(index)}>Remover</button>
            <button onClick={() => onAlterarStatus(index)}>Alterar Status</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ListaAnimais;
